import { useNavigation } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import * as WebBrowser from 'expo-web-browser';
import React from "react";
import { Image, Pressable, ScrollView, StyleSheet, Text, TextInput, View } from "react-native";

function openLink(url) {
  WebBrowser.openBrowserAsync(url);
}

function getInvestment (sharePrice, numberShares) {
  const investment = sharePrice * numberShares;
  return investment.toFixed(2);
}

function HomeScreen() {
  const navigation = useNavigation();
  const [symbol, setSymbol] = React.useState('');
  const [sharePrice, setSharePrice] = React.useState('');
  const [numberShares, setnumberShares] = React.useState('');
  const [investment, setInvestment] = React.useState('');
  return (
    <View style={styles.HomeScreen}>
      <Text style={styles.Title}>Stock App</Text>

      <View style={styles.HomeContent}>

        <Pressable onPress={() => openLink("https://finance.yahoo.com/")}>
          <Text style={styles.Link}>Yahoo Finance</Text>
        </Pressable>

        <View style={styles.Inputs}>
          <TextInput style={styles.Input} placeholder='Stock Symbol' onChangeText={setSymbol} />
          <TextInput style={styles.Input} placeholder='Price Per Share' onChangeText={setSharePrice} keyboardType='numeric' />
          <TextInput style={styles.Input} placeholder='Number of Shares' onChangeText={setnumberShares} keyboardType='numeric' />
        </View>

        {(sharePrice && numberShares && !isNaN(parseFloat(sharePrice)) && !isNaN(parseFloat(numberShares)))
          ? <Text style={styles.Preview}>Investment total: ${(parseFloat(sharePrice) * parseFloat(numberShares)).toFixed(2)} </Text>
          : <Text style={styles.Preview}>Investment total: </Text>}

        <View style={styles.Buttons}>
          <Pressable style={styles.Button} onPress={() => navigation.navigate('Investments', {
            symbol: symbol, sharePrice: sharePrice, numberShares: numberShares,
          })}>
            <Text style={styles.ButtonText}>
              Add Investment
            </Text>
          </Pressable >
          <Pressable style={styles.Button} onPress={() => navigation.navigate('Investments', {
            symbol: symbol, sharePrice: sharePrice, numberShares: numberShares,
          })}>
            <Text style={styles.ButtonText}>Go to Investments</Text>
          </Pressable >
        </View>

      </View>

    </View >
  );
}

function InvestmentScreen({ route }) {
  const { symbol, sharePrice, numberShares } = route.params;
  return (
    <View style={styles.InvestmentScreen}>
      <Image style={styles.Image} source={require('@/assets/images/stocks.png')} />
      <View style={styles.Summary}>
        <Text style={styles.SubTitle}>Investment History</Text>
        <ScrollView>
          <Text style={styles.Details}>
            {symbol} Investment {'\n'} Share: {sharePrice}, shares: {numberShares}, investment: {getInvestment(sharePrice, numberShares)}
          </Text>
        </ScrollView>
      </View>
    </View>
  );
}

const Stack = createNativeStackNavigator();

function RootStack() {
  return (
    <Stack.Navigator initialRouteName="Home" screenOptions={{
      headerStyle: {
        backgroundColor: '#0096FF',
      }
    }}>
      <Stack.Screen name="Home" component={HomeScreen} options={{ title: '', headerShown: false }} />
      <Stack.Screen name="Investments" component={InvestmentScreen} options={{ title: 'back' }} />
    </Stack.Navigator>
  );
}

export default function App() {
  return (
    <RootStack />
  );
}

const styles = StyleSheet.create({
  HomeScreen: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#F0FFFF',
  },
  HomeContent: {
    flex: 2,
    marginVertical: 30,
  },
  InvestmentScreen: {
    flex: 1,
    alignItems: 'center',
    backgroundColor: '#F0FFFF',
  },
  Summary: {
    borderWidth: 1,
    width: 300,
  },
  Title: {
    textAlign: 'center',
    fontSize: 50,
    fontWeight: 'bold',
    backgroundColor: '#0096FF',
    padding: 20,
    marginBottom: 10,
    width: 360,
  },
  Link: {
    fontSize: 25,
    color: 'blue',
    textDecorationLine: 'underline',
    marginBottom: 10,
    textAlign: 'center'
  },
  Preview: {
    fontSize: 25,
    width: 300,
    textAlign: 'center'
  },
  SubTitle: {
    textAlign: 'center',
    fontSize: 30,
    backgroundColor: '#0096FF',
    padding: 5,
    
  },
  Details: {
    fontSize: 20,
    marginHorizontal: 50,
    marginVertical: 5,
  },
  Image: {
    width: 300,
    height: 200,
    marginTop: 200,
    marginHorizontal: 'auto',
  },
  Inputs: {
    marginHorizontal: 'auto',
    marginTop: 10,
    marginBottom: 10,
    width: 275,
  },
  Input: {
    height: 50,
    margin: 5,
    padding: 5,
    fontSize: 25,
    backgroundColor: "#ecf0f1",
    borderWidth: 1,
    borderRadius: 3,
  },
  Buttons: {
    marginHorizontal: 'auto',
    marginTop: 10,
    marginBottom: 10,
    width: 300,
  },
  Button: {
    height: 75,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#0096FF',
    margin: 5,
    borderRadius: 10,
    color: 'white',
    padding: 10,
  },
  ButtonText: {
    fontSize: 25,
    textAlign: 'center',
    color: 'white',
  },

})